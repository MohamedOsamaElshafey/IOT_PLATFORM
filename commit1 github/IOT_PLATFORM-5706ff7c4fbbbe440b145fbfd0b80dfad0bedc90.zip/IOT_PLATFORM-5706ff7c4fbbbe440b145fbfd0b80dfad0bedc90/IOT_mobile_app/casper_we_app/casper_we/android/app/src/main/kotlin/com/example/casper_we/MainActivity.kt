package com.example.casper_we

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
