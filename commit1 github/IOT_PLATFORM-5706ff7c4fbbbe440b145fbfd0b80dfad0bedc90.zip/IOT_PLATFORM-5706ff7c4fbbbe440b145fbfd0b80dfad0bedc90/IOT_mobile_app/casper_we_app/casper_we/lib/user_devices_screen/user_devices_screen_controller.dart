import 'package:casper_we/libraries.dart';

class UserDevicesPageController extends GetxController {
  // This controller can be expanded to manage user devices data
}
